#include <iostream>
#include <unordered_map>
#include <algorithm>
#include <vector>
#include <string>

// Function to tokenize a string into individual words
std::vector<std::string> tokenize(const std::string& text) {
    std::vector<std::string> tokens;
    std::string word = "";
    for (char c : text) {
        if (std::isspace(c)) {
            if (!word.empty()) {
                tokens.push_back(word);
                word = "";
            }
        }
        else {
            word += c;
        }
    }
    if (!word.empty()) {
        tokens.push_back(word);
    }
    return tokens;
}

// Search engine class
class SearchEngine {
private:
    std::unordered_map<std::string, std::vector<int>> invertedIndex;

public:
    // Index a document with its corresponding document ID
    void indexDocument(const std::string& document, int documentId) {
        std::vector<std::string> tokens = tokenize(document);
        for (const std::string& token : tokens) {
            invertedIndex[token].push_back(documentId);
        }
    }

    // Search for documents containing the given query
    std::vector<int> search(const std::string& query) {
        std::string lowerQuery = query;
        std::transform(lowerQuery.begin(), lowerQuery.end(), lowerQuery.begin(), ::tolower);
        
        std::vector<std::string> tokens = tokenize(lowerQuery);
        std::vector<int> result;
        for (const std::string& token : tokens) {
            if (invertedIndex.count(token) > 0) {
                std::vector<int> documentIds = invertedIndex[token];
                result.insert(result.end(), documentIds.begin(), documentIds.end());
            }
        }
        return result;
    }
};

int main() {
    SearchEngine searchEngine;

    // Index some example documents
    searchEngine.indexDocument("The quick brown fox jumps over the lazy dog", 1);
    searchEngine.indexDocument("The lazy dog loves to sleep", 2);
    searchEngine.indexDocument("The quick fox likes to run", 3);

    // Perform a search
    std::vector<int> searchResult = searchEngine.search("quick dog");
    
    // Print the search result
    std::cout << "Search Result:" << std::endl;
    for (int documentId : searchResult) {
        std::cout << "Document ID: " << documentId << std::endl;
    }

    return 0;
}
    